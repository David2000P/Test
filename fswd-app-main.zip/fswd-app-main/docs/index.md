---
title: Home
nav_order: 0
---

{: .attention }
> Any text enclosed by `[ ]` are placeholders, including the opening and closing brackets.
>
> You may delete this `attention` box.

# [Project Name]

[Project description]

## Team members

### [Jane Dane]

About
: Some info about Jane

Matr.-Nr.
: 1234567

### [Joe Doe]

About
: Some info about Joe

Matr.-Nr.
: 1234567

## Eidesstattliche Erklärung

Die oben genannten Teammitglieder erklären an Eides statt:

> Diese Arbeit wurde selbständig und eigenhändig erstellt. Die den benutzten Quellen wörtlich oder inhaltlich entommenen Stellen sind als solche kenntlich gemacht. Diese Erklärung gilt für jeglichen Inhalt und umfasst sowohl diese Dokumentation als auch den als Projektergebnis eingereichten Quellcode.

{: .fs-2 }
Last build: {{ site.time | date: '%d %b %Y, %R%:z' }}