---
title: Peer Review
parent: Team Evaluation
nav_order: 3
---

{: .label }
[Jane Dane]

{: .no_toc }
# Peer review

<details open markdown="block">
{: .text-delta }
<summary>Table of contents</summary>
+ ToC
{: toc }
</details>

## [team member] - review 1

### My observation (Wahrnehmung)

[A specific observation, regarding know-how, effectiveness, team work or from another relevant area]

### Effect on me (Wirkung)

[What positive or negative effect did this observation have on the reviewer?]

### Tip for the future (Wunsch)

[What should be changed or strengthened for the point of view of the reviewer?]