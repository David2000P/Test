---
title: Goals
parent: Team Evaluation
nav_order: 1
---

{: .label }
[Jane Dane]

{: .no_toc }
# Goals achieved and missed

<details open markdown="block">
{: .text-delta }
<summary>Table of contents</summary>
+ ToC
{: toc }
</details>
