---
title: Contributions
parent: Team Evaluation
nav_order: 4
---

{: .label }
[Jane Dane]

{: .no_toc }
# Summary of individual contributions

<details open markdown="block">
{: .text-delta }
<summary>Table of contents</summary>
+ ToC
{: toc }
</details>

## [Jane Dane]

Contributions
: Lorem ipsum dolor
: Consetetur sadipscing elitr
: ...

## [Joe Doe]

Contributions
: Diam nonumy eirmod
: Tempor invidunt ut labore
: ...
